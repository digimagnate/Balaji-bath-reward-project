let token = localStorage.getItem('bbsl_admin_token') || null;

function money(n){ return '₹' + Number(n || 0).toLocaleString('en-IN', {maximumFractionDigits:0}); }

function showToast(message, type = 'success') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = 'toast' + (type === 'error' ? ' toast-error' : '');
  toast.innerHTML = `<span class="toast-icon">${type === 'error' ? '!' : '✓'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('toast-out');
    toast.addEventListener('animationend', () => toast.remove(), { once: true });
  }, 3200);
}

async function api(path, opts = {}) {
  opts.headers = opts.headers || {};
  if (token) opts.headers['Authorization'] = 'Bearer ' + token;
  if (opts.body) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(opts.body); }
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw data;
  return data;
}

// ---------------- RIPPLE EFFECT (buttons) ----------------
document.addEventListener('click', (e) => {
  const btn = e.target.closest('.btn');
  if (!btn || btn.disabled) return;
  const rect = btn.getBoundingClientRect();
  const ripple = document.createElement('span');
  const size = Math.max(rect.width, rect.height);
  ripple.className = 'ripple';
  ripple.style.width = ripple.style.height = size + 'px';
  ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
  ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
});

// ---------------- REASON MODAL (replaces native prompt()) ----------------
function showReasonModal(title) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-box">
        <h4>✏️ ${title}</h4>
        <textarea id="modalReason" rows="3" placeholder="Enter a reason..."></textarea>
        <div class="modal-actions">
          <button class="btn btn-ghost btn-sm" id="modalCancel">Cancel</button>
          <button class="btn btn-bad btn-sm" id="modalConfirm">Confirm</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    const textarea = overlay.querySelector('#modalReason');
    setTimeout(() => textarea.focus(), 50);
    const close = (val) => { overlay.remove(); resolve(val); };
    overlay.querySelector('#modalCancel').onclick = () => close(null);
    overlay.querySelector('#modalConfirm').onclick = () => close(textarea.value.trim() || 'Not specified');
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(null); });
  });
}

// ---------------- COUNT-UP ANIMATION ----------------
function animateValue(el, endValue, isMoney = false) {
  const duration = 700, start = performance.now();
  function step(now) {
    const p = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    const val = endValue * eased;
    el.textContent = isMoney ? money(val) : Math.round(val);
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ---------------- CONFETTI ----------------
function celebrate() {
  const colors = ['#cda45e', '#e8c98a', '#7fad8b', '#ffffff'];
  for (let i = 0; i < 28; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    piece.style.left = Math.random() * 100 + 'vw';
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDelay = (Math.random() * 0.25) + 's';
    piece.style.transform = `rotate(${Math.random() * 360}deg)`;
    document.body.appendChild(piece);
    setTimeout(() => piece.remove(), 1800);
  }
}

async function adminLogin() {
  const username = document.getElementById('adminUser').value.trim();
  const password = document.getElementById('adminPass').value;
  const errEl = document.getElementById('loginErr'); errEl.classList.add('hidden');
  try {
    const data = await api('/api/admin/login', { method: 'POST', body: { username, password } });
    token = data.token; localStorage.setItem('bbsl_admin_token', token);
    showToast('Welcome back, admin.');
    enterPanel();
  } catch (e) {
    errEl.textContent = e.error || 'Login failed.'; errEl.classList.remove('hidden');
    showToast(e.error || 'Login failed.', 'error');
  }
}

function adminLogout() {
  localStorage.removeItem('bbsl_admin_token'); token = null;
  document.getElementById('panelScreen').classList.add('hidden');
  document.getElementById('loginScreen').classList.remove('hidden');
  document.getElementById('topRight').innerHTML = '';
}

async function enterPanel() {
  try {
    const s = await api('/api/admin/stats');
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('panelScreen').classList.remove('hidden');
    document.getElementById('topRight').innerHTML = `<button class="btn btn-ghost btn-sm" onclick="adminLogout()">Log Out</button>`;
    document.getElementById('stMembers').textContent = 0; animateValue(document.getElementById('stMembers'), s.members);
    document.getElementById('stPendingInv').textContent = 0; animateValue(document.getElementById('stPendingInv'), s.pending_invoices);
    document.getElementById('stPendingRed').textContent = 0; animateValue(document.getElementById('stPendingRed'), s.pending_redemptions);
    document.getElementById('stPointsIssued').textContent = '₹0'; animateValue(document.getElementById('stPointsIssued'), s.points_issued, true);
    loadInvoices(); loadRedemptions(); loadMembers();
  } catch (e) {
    adminLogout();
  }
}

document.getElementById('adminTabs').addEventListener('click', (e) => {
  const btn = e.target.closest('button'); if (!btn) return;
  document.querySelectorAll('#adminTabs button').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  ['invoices', 'redemptions', 'members'].forEach(t =>
    document.getElementById('pane-' + t).classList.toggle('hidden', t !== btn.dataset.tab));
});

async function loadInvoices() {
  const rows = await api('/api/admin/invoices?status=pending');
  const tbody = document.querySelector('#invoiceTable tbody');
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td data-label="Member">${r.full_name}<br><span class="muted">${r.member_code}</span></td>
      <td data-label="Category">${r.category}</td>
      <td data-label="Invoice #">${r.invoice_number}</td>
      <td data-label="Date">${r.invoice_date}</td>
      <td data-label="Amount">${money(r.invoice_amount)}</td>
      <td data-label="File">${r.file_path ? `<a href="${r.file_path}" target="_blank">View</a>` : '—'}</td>
      <td data-label="Action" class="td-actions">
        <button class="btn btn-gold btn-sm" onclick="verifyInvoice(${r.id})">Verify</button>
        <button class="btn btn-bad btn-sm" onclick="rejectInvoice(${r.id})">Reject</button>
      </td>
    </tr>`).join('') || '<tr><td colspan="7" class="muted">No pending invoices.</td></tr>';
}

async function verifyInvoice(id) {
  try {
    const r = await api(`/api/admin/invoices/${id}/verify`, { method: 'POST' });
    showToast(`Invoice verified — ${money(r.points_awarded)} points credited.`);
    celebrate();
    loadInvoices(); enterPanel();
  } catch (e) { showToast(e.error || 'Could not verify.', 'error'); }
}
async function rejectInvoice(id) {
  const reason = await showReasonModal('Reason for rejecting this invoice');
  if (reason === null) return;
  try {
    await api(`/api/admin/invoices/${id}/reject`, { method: 'POST', body: { reason } });
    showToast('Invoice rejected.', 'error');
    loadInvoices(); enterPanel();
  } catch (e) { showToast(e.error || 'Could not reject.', 'error'); }
}

async function loadRedemptions() {
  const rows = await api('/api/admin/redemptions?status=pending');
  const tbody = document.querySelector('#redemptionTable tbody');
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td data-label="Member">${r.full_name}<br><span class="muted">${r.member_code}</span></td>
      <td data-label="Gift">${r.item_name}</td>
      <td data-label="Points">${money(r.points_deducted)}</td>
      <td data-label="Collection date" class="td-input"><input type="date" id="date-${r.id}" style="margin:0; padding:6px 8px;"></td>
      <td data-label="Message" class="td-input"><input type="text" id="msg-${r.id}" placeholder="Collection note" style="margin:0; padding:6px 8px;"></td>
      <td data-label="Action" class="td-actions">
        <button class="btn btn-gold btn-sm" onclick="approveRedemption(${r.id})">Approve</button>
        <button class="btn btn-bad btn-sm" onclick="rejectRedemption(${r.id})">Reject</button>
      </td>
    </tr>`).join('') || '<tr><td colspan="6" class="muted">No pending redemptions.</td></tr>';
}

async function approveRedemption(id) {
  const collection_date = document.getElementById(`date-${id}`).value;
  const collection_message = document.getElementById(`msg-${id}`).value;
  try {
    await api(`/api/admin/redemptions/${id}/approve`, { method: 'POST', body: { collection_date, collection_message } });
    showToast('Redemption approved.');
    celebrate();
    loadRedemptions(); enterPanel();
  } catch (e) { showToast(e.error || 'Could not approve.', 'error'); }
}
async function rejectRedemption(id) {
  const reason = await showReasonModal('Reason for rejecting this redemption');
  if (reason === null) return;
  try {
    await api(`/api/admin/redemptions/${id}/reject`, { method: 'POST', body: { reason } });
    showToast('Redemption rejected.', 'error');
    loadRedemptions(); enterPanel();
  } catch (e) { showToast(e.error || 'Could not reject.', 'error'); }
}

async function loadMembers() {
  const rows = await api('/api/admin/members');
  const tbody = document.querySelector('#memberTable tbody');
  tbody.innerHTML = rows.map(m => `
    <tr>
      <td data-label="Member Code">${m.member_code}</td>
      <td data-label="Name">${m.full_name}</td>
      <td data-label="Mobile">${m.mobile}</td>
      <td data-label="Category">${m.category}</td>
      <td data-label="Balance">${money(m.balance)}</td>
      <td data-label="Joined">${new Date(m.created_at).toLocaleDateString('en-IN')}</td>
    </tr>`).join('') || '<tr><td colspan="6" class="muted">No members yet.</td></tr>';
}

if (token) enterPanel();
