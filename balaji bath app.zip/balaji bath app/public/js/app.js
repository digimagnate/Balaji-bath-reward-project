const API = '';
let token = localStorage.getItem('bbsl_token') || null;

function money(n){ return '₹' + Number(n || 0).toLocaleString('en-IN', {maximumFractionDigits:0}); }

function showToast(message, type = 'success') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = 'toast' + (type === 'error' ? ' toast-error' : '');
  toast.innerHTML = `<span class="toast-icon">${type === 'error' ? '!' : '✓'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('toast-out');
    toast.addEventListener('animationend', () => toast.remove(), { once: true });
  }, 3200);
}

async function api(path, opts = {}) {
  opts.headers = opts.headers || {};
  if (token) opts.headers['Authorization'] = 'Bearer ' + token;
  if (opts.body && !(opts.body instanceof FormData)) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(opts.body);
  }
  const res = await fetch(API + path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw data;
  return data;
}

// ---------------- COUNT-UP ANIMATION ----------------
function animateValue(el, endValue, isMoney = false) {
  const duration = 700, start = performance.now();
  function step(now) {
    const p = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    const val = endValue * eased;
    el.textContent = isMoney ? money(val) : Math.round(val);
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ---------------- CONFETTI ----------------
function celebrate() {
  const colors = ['#cda45e', '#e8c98a', '#7fad8b', '#ffffff'];
  for (let i = 0; i < 28; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    piece.style.left = Math.random() * 100 + 'vw';
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDelay = (Math.random() * 0.25) + 's';
    piece.style.transform = `rotate(${Math.random() * 360}deg)`;
    document.body.appendChild(piece);
    setTimeout(() => piece.remove(), 1800);
  }
}

// ---------------- RIPPLE EFFECT (buttons) ----------------
document.addEventListener('click', (e) => {
  const btn = e.target.closest('.btn');
  if (!btn || btn.disabled) return;
  const rect = btn.getBoundingClientRect();
  const ripple = document.createElement('span');
  const size = Math.max(rect.width, rect.height);
  ripple.className = 'ripple';
  ripple.style.width = ripple.style.height = size + 'px';
  ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
  ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
});

// ---------------- CATEGORY CHIP SELECTOR ----------------
let selectedCategory = 'plumber';
const chipGroup = document.getElementById('categoryChips');
if (chipGroup) {
  chipGroup.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip'); if (!chip) return;
    chipGroup.querySelectorAll('.chip').forEach(c => c.classList.remove('selected'));
    chip.classList.add('selected');
    selectedCategory = chip.dataset.value;
  });
}

// ---------------- AUTH TABS ----------------
function resetAuthSteps() {
  ['loginStep1','regStep1'].forEach(id => document.getElementById(id).classList.remove('hidden'));
  ['loginStep2','regStep2'].forEach(id => document.getElementById(id).classList.add('hidden'));
  ['loginDot1','regDot1'].forEach(id => { document.getElementById(id).classList.remove('done'); document.getElementById(id).classList.add('current'); });
  ['loginDot2','regDot2'].forEach(id => document.getElementById(id).classList.remove('current'));
}
document.getElementById('authTabs').addEventListener('click', (e) => {
  const btn = e.target.closest('button'); if (!btn) return;
  document.querySelectorAll('#authTabs button').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('loginPane').classList.toggle('hidden', btn.dataset.tab !== 'login');
  document.getElementById('registerPane').classList.toggle('hidden', btn.dataset.tab !== 'register');
});

async function requestOtp(kind) {
  const mobileEl = document.getElementById(kind === 'login' ? 'loginMobile' : 'regMobile');
  const errEl = document.getElementById(kind === 'login' ? 'loginErr1' : 'regErr1');
  const mobile = mobileEl.value.trim();
  errEl.classList.add('hidden');
  if (!/^[6-9]\d{9}$/.test(mobile)) { errEl.textContent = 'Enter a valid 10-digit mobile number.'; errEl.classList.remove('hidden'); return; }

  try {
    const data = await api('/api/otp/request', { method: 'POST', body: { mobile } });
    if (kind === 'login') {
      document.getElementById('loginStep1').classList.add('hidden');
      document.getElementById('loginStep2').classList.remove('hidden', 'fade-up'); void document.getElementById('loginStep2').offsetWidth; document.getElementById('loginStep2').classList.add('fade-up');
      document.getElementById('loginDot1').classList.add('done'); document.getElementById('loginDot1').classList.remove('current');
      document.getElementById('loginDot2').classList.add('current');
      document.getElementById('loginHint').textContent = data.dev_otp ? `Dev mode — your OTP is ${data.dev_otp}` : 'OTP sent to your mobile.';
      showToast('OTP sent to your mobile.');
    } else {
      document.getElementById('regStep1').classList.add('hidden');
      document.getElementById('regStep2').classList.remove('hidden', 'fade-up'); void document.getElementById('regStep2').offsetWidth; document.getElementById('regStep2').classList.add('fade-up');
      document.getElementById('regDot1').classList.add('done'); document.getElementById('regDot1').classList.remove('current');
      document.getElementById('regDot2').classList.add('current');
      document.getElementById('regHint').textContent = data.dev_otp ? `Dev mode — your OTP is ${data.dev_otp}` : 'OTP sent to your mobile.';
      showToast('OTP sent to your mobile.');
    }
  } catch (e) {
    errEl.textContent = e.error || 'Could not send OTP.'; errEl.classList.remove('hidden');
    showToast(e.error || 'Could not send OTP.', 'error');
  }
}

async function doLogin() {
  const mobile = document.getElementById('loginMobile').value.trim();
  const otp = document.getElementById('loginOtp').value.trim();
  const errEl = document.getElementById('loginErr2'); errEl.classList.add('hidden');
  try {
    const data = await api('/api/login', { method: 'POST', body: { mobile, otp } });
    token = data.token; localStorage.setItem('bbsl_token', token);
    showToast(`Welcome back — logged in as ${data.member_code}.`);
    enterDashboard();
  } catch (e) {
    errEl.textContent = e.error || 'Login failed.'; errEl.classList.remove('hidden');
    showToast(e.error || 'Login failed.', 'error');
  }
}

async function doRegister() {
  const mobile = document.getElementById('regMobile').value.trim();
  const otp = document.getElementById('regOtp').value.trim();
  const full_name = document.getElementById('regName').value.trim();
  const category = selectedCategory;
  const email = document.getElementById('regEmail').value.trim();
  const city = document.getElementById('regCity').value.trim();
  const address = document.getElementById('regAddress').value.trim();
  const errEl = document.getElementById('regErr2'); errEl.classList.add('hidden');

  if (!full_name) {
    errEl.textContent = 'Please enter your full name.'; errEl.classList.remove('hidden');
    showToast('Please enter your full name.', 'error');
    return;
  }

  try {
    const data = await api('/api/register', { method: 'POST', body: { mobile, otp, full_name, category, email, city, address } });
    token = data.token; localStorage.setItem('bbsl_token', token);
    showToast(`Account created — welcome, ${full_name.split(' ')[0]}! Your member ID is ${data.member_code}.`);
    enterDashboard();
  } catch (e) {
    errEl.textContent = e.error || 'Registration failed.'; errEl.classList.remove('hidden');
    showToast(e.error || 'Registration failed.', 'error');
  }
}

function logout() {
  localStorage.removeItem('bbsl_token'); token = null;
  document.getElementById('dashScreen').classList.add('hidden');
  document.getElementById('authScreen').classList.remove('hidden');
  document.getElementById('topRight').innerHTML = '';
  resetAuthSteps();
}

// ---------------- DASHBOARD ----------------
async function enterDashboard() {
  try {
    const d = await api('/api/dashboard');
    document.getElementById('authScreen').classList.add('hidden');
    document.getElementById('dashScreen').classList.remove('hidden');
    document.getElementById('topRight').innerHTML = `
      <div class="member-chip">
        <span>${d.full_name} &middot; <strong>${d.member_code}</strong> &middot; ${d.category}</span>
        <button class="btn btn-ghost btn-sm" onclick="logout()">Log Out</button>
      </div>`;
    animateValue(document.getElementById('stBalance'), d.available_balance, true);
    animateValue(document.getElementById('stPurchases'), d.total_purchases, true);
    animateValue(document.getElementById('stPendingInv'), d.pending_invoices);
    animateValue(document.getElementById('stPendingRed'), d.pending_redemptions);
    loadInvoices(); loadCatalogue(); loadRedemptions();
  } catch (e) {
    logout();
  }
}

document.getElementById('dashTabs').addEventListener('click', (e) => {
  const btn = e.target.closest('button'); if (!btn) return;
  document.querySelectorAll('#dashTabs button').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  ['submit', 'invoices', 'catalogue', 'redemptions'].forEach(t =>
    document.getElementById('pane-' + t).classList.toggle('hidden', t !== btn.dataset.tab));
});

document.getElementById('invoiceForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('invErr'), okEl = document.getElementById('invOk');
  errEl.classList.add('hidden'); okEl.classList.add('hidden');

  const fd = new FormData();
  fd.append('invoice_number', document.getElementById('invNumber').value);
  fd.append('invoice_date', document.getElementById('invDate').value);
  fd.append('invoice_amount', document.getElementById('invAmount').value);
  fd.append('remarks', document.getElementById('invRemarks').value);
  const file = document.getElementById('invFile').files[0];
  if (file) fd.append('file', file);

  try {
    await api('/api/invoices', { method: 'POST', body: fd });
    okEl.textContent = 'Invoice submitted — it will appear as pending until reviewed.'; okEl.classList.remove('hidden');
    showToast('Invoice submitted for verification.');
    e.target.reset();
    loadInvoices(); enterDashboard();
  } catch (e2) {
    errEl.textContent = e2.error || 'Could not submit invoice.'; errEl.classList.remove('hidden');
    showToast(e2.error || 'Could not submit invoice.', 'error');
  }
});

async function loadInvoices() {
  const rows = await api('/api/invoices/mine');
  const tbody = document.querySelector('#invoiceTable tbody');
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td data-label="Invoice #">${r.invoice_number}</td>
      <td data-label="Date">${r.invoice_date}</td>
      <td data-label="Amount">${money(r.invoice_amount)}</td>
      <td data-label="Status"><span class="badge badge-${r.status}">${r.status}</span></td>
      <td data-label="Points">${r.points_awarded ? money(r.points_awarded) : '—'}</td>
    </tr>`).join('') || '<tr><td colspan="5" class="muted">No invoices submitted yet.</td></tr>';
}

async function loadCatalogue() {
  const items = await api('/api/catalogue');
  const d = await api('/api/dashboard');
  const grid = document.getElementById('catalogueGrid');
  grid.innerHTML = items.map(g => `
    <div class="gift-card">
      <div class="pts">${money(g.slab_points)}</div>
      <div class="item">${g.item_name}</div>
      <button class="btn ${d.available_balance >= g.slab_points ? 'btn-gold' : 'btn-ghost'} btn-sm" style="width:100%"
        ${d.available_balance >= g.slab_points ? '' : 'disabled'} onclick="redeem(${g.id})">
        ${d.available_balance >= g.slab_points ? 'Redeem' : 'Not enough points'}
      </button>
    </div>`).join('');
}

async function redeem(giftId) {
  try {
    await api('/api/redemptions', { method: 'POST', body: { gift_id: giftId } });
    showToast('Redemption request sent for approval.');
    celebrate();
    loadCatalogue(); loadRedemptions(); enterDashboard();
  } catch (e) {
    showToast(e.error || 'Could not create redemption request.', 'error');
  }
}

async function loadRedemptions() {
  const rows = await api('/api/redemptions/mine');
  const tbody = document.querySelector('#redemptionTable tbody');
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td data-label="Gift">${r.item_name}</td>
      <td data-label="Points">${money(r.points_deducted)}</td>
      <td data-label="Status"><span class="badge badge-${r.status}">${r.status}</span></td>
      <td data-label="Collection">${r.collection_date ? r.collection_date + (r.collection_message ? ' — ' + r.collection_message : '') : '—'}</td>
    </tr>`).join('') || '<tr><td colspan="4" class="muted">No redemption requests yet.</td></tr>';
}

// ---------------- BOOT ----------------
if (token) enterDashboard();
