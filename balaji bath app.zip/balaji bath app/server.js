const express = require('express');
const cors = require('cors');
const multer = require('multer');
const crypto = require('crypto');
const path = require('path');
const { data, save, nextId, REWARD_RATES, getBalance, getAvailableBalance } = require('./store');
const otp = require('./otp');

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, path.join(__dirname, 'uploads')),
    filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g, '_')),
  }),
  limits: { fileSize: 8 * 1024 * 1024 },
});

// ---------- sessions ----------
function issueSession(role, memberId) {
  const token = crypto.randomBytes(24).toString('hex');
  const expires = Date.now() + 7 * 24 * 60 * 60 * 1000;
  data.sessions.push({ token, member_id: memberId || null, role, expires_at: expires });
  save();
  return token;
}

function auth(requiredRole) {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    if (!header.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing token.' });
    const token = header.slice(7).trim();
    const session = data.sessions.find(s => s.token === token);
    if (!session) return res.status(401).json({ error: 'Invalid session.' });
    if (session.expires_at < Date.now()) return res.status(401).json({ error: 'Session expired.' });
    if (requiredRole && session.role !== requiredRole) return res.status(403).json({ error: 'Forbidden.' });
    req.session = session;
    next();
  };
}

// =====================================================================
// MEMBER: OTP + registration + login
// =====================================================================

app.post('/api/otp/request', (req, res) => {
  const { mobile } = req.body;
  if (!/^[6-9]\d{9}$/.test(mobile || '')) return res.status(400).json({ error: 'Enter a valid 10-digit mobile number.' });
  const generated = otp.generate(mobile);
  const payload = { success: true, message: 'OTP sent.' };
  if (!isProd) payload.dev_otp = generated;
  res.json(payload);
});

app.post('/api/register', (req, res) => {
  const { mobile, otp: code, full_name, category, email, address, city } = req.body;
  if (!otp.verify(mobile, code)) return res.status(401).json({ error: 'Incorrect or expired OTP.' });
  if (!['plumber', 'contractor', 'architect'].includes(category)) return res.status(400).json({ error: 'Invalid category.' });

  if (data.members.find(m => m.mobile === mobile)) {
    return res.status(409).json({ error: 'This mobile number is already registered. Please log in instead.' });
  }

  const member = {
    id: nextId('members'),
    member_code: 'BBS-' + String(Math.floor(1000 + Math.random() * 9000)),
    full_name, mobile, email: email || null, category,
    address: address || null, city: city || null,
    created_at: new Date().toISOString(),
  };
  data.members.push(member);
  save();

  const token = issueSession('member', member.id);
  res.json({ success: true, token, member_code: member.member_code });
});

app.post('/api/login', (req, res) => {
  const { mobile, otp: code } = req.body;
  if (!otp.verify(mobile, code)) return res.status(401).json({ error: 'Incorrect or expired OTP.' });
  const member = data.members.find(m => m.mobile === mobile);
  if (!member) return res.status(404).json({ error: 'No account found for this number. Please register first.', not_registered: true });
  const token = issueSession('member', member.id);
  res.json({ success: true, token, member_code: member.member_code });
});

// =====================================================================
// MEMBER: dashboard, invoices, catalogue, redemptions
// =====================================================================

app.get('/api/dashboard', auth('member'), (req, res) => {
  const memberId = req.session.member_id;
  const member = data.members.find(m => m.id === memberId);
  const totalPurchases = data.invoices
    .filter(i => i.member_id === memberId && i.status === 'verified')
    .reduce((s, i) => s + i.invoice_amount, 0);
  const pendingInvoices = data.invoices.filter(i => i.member_id === memberId && i.status === 'pending').length;
  const pendingRedemptions = data.redemptions.filter(r => r.member_id === memberId && r.status === 'pending').length;
  const redeemedCount = data.redemptions.filter(r => r.member_id === memberId && ['approved', 'collected'].includes(r.status)).length;

  res.json({
    member_code: member.member_code,
    full_name: member.full_name,
    category: member.category,
    reward_rate: REWARD_RATES[member.category],
    balance: getBalance(memberId),
    available_balance: getAvailableBalance(memberId),
    total_purchases: totalPurchases,
    pending_invoices: pendingInvoices,
    pending_redemptions: pendingRedemptions,
    redeemed_count: redeemedCount,
  });
});

app.get('/api/invoices/mine', auth('member'), (req, res) => {
  const rows = data.invoices
    .filter(i => i.member_id === req.session.member_id)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json(rows);
});

app.post('/api/invoices', auth('member'), upload.single('file'), (req, res) => {
  const { invoice_number, invoice_date, invoice_amount, remarks } = req.body;
  if (!invoice_number || !invoice_date || !invoice_amount) return res.status(400).json({ error: 'Invoice number, date and amount are required.' });

  data.invoices.push({
    id: nextId('invoices'),
    member_id: req.session.member_id,
    invoice_number, invoice_date,
    invoice_amount: parseFloat(invoice_amount),
    file_path: req.file ? '/uploads/' + req.file.filename : null,
    remarks: remarks || null,
    status: 'pending',
    reject_reason: null,
    points_awarded: null,
    created_at: new Date().toISOString(),
    reviewed_at: null,
  });
  save();

  res.json({ success: true, message: 'Invoice submitted for verification.' });
});

app.get('/api/catalogue', (req, res) => {
  const rows = data.gift_catalogue.filter(g => g.active).sort((a, b) => a.slab_points - b.slab_points);
  res.json(rows);
});

app.get('/api/redemptions/mine', auth('member'), (req, res) => {
  const rows = data.redemptions
    .filter(r => r.member_id === req.session.member_id)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .map(r => ({ ...r, item_name: data.gift_catalogue.find(g => g.id === r.gift_id)?.item_name || 'Gift' }));
  res.json(rows);
});

app.post('/api/redemptions', auth('member'), (req, res) => {
  const { gift_id } = req.body;
  const gift = data.gift_catalogue.find(g => g.id === gift_id && g.active);
  if (!gift) return res.status(404).json({ error: 'Gift not found.' });

  const available = getAvailableBalance(req.session.member_id);
  if (available < gift.slab_points) return res.status(400).json({ error: 'Not enough points for this gift.' });

  data.redemptions.push({
    id: nextId('redemptions'),
    member_id: req.session.member_id,
    gift_id: gift.id,
    points_deducted: gift.slab_points,
    status: 'pending',
    collection_date: null,
    collection_message: null,
    reject_reason: null,
    created_at: new Date().toISOString(),
    reviewed_at: null,
  });
  save();

  res.json({ success: true, message: 'Redemption request sent for approval.' });
});

// =====================================================================
// ADMIN: login + approvals
// =====================================================================

app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  const admin = data.admin_users.find(a => a.username === username && a.password === password);
  if (!admin) return res.status(401).json({ error: 'Invalid admin credentials.' });
  const token = issueSession('admin', null);
  res.json({ success: true, token });
});

app.get('/api/admin/stats', auth('admin'), (req, res) => {
  res.json({
    members: data.members.length,
    pending_invoices: data.invoices.filter(i => i.status === 'pending').length,
    pending_redemptions: data.redemptions.filter(r => r.status === 'pending').length,
    points_issued: data.points_transactions.filter(t => t.type === 'earned').reduce((s, t) => s + t.points, 0),
  });
});

app.get('/api/admin/invoices', auth('admin'), (req, res) => {
  const status = req.query.status || 'pending';
  const rows = data.invoices
    .filter(i => i.status === status)
    .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
    .map(i => {
      const m = data.members.find(m => m.id === i.member_id);
      return { ...i, full_name: m?.full_name, member_code: m?.member_code, category: m?.category };
    });
  res.json(rows);
});

app.post('/api/admin/invoices/:id/verify', auth('admin'), (req, res) => {
  const invoice = data.invoices.find(i => i.id === parseInt(req.params.id));
  if (!invoice) return res.status(404).json({ error: 'Invoice not found.' });
  if (invoice.status !== 'pending') return res.status(400).json({ error: 'Invoice already reviewed.' });

  const member = data.members.find(m => m.id === invoice.member_id);
  const points = Math.round(invoice.invoice_amount * REWARD_RATES[member.category] * 100) / 100;

  invoice.status = 'verified';
  invoice.points_awarded = points;
  invoice.reviewed_at = new Date().toISOString();

  data.points_transactions.push({
    id: nextId('points_transactions'),
    member_id: invoice.member_id,
    invoice_id: invoice.id,
    redemption_id: null,
    type: 'earned',
    points,
    note: `Invoice ${invoice.invoice_number}`,
    created_at: new Date().toISOString(),
  });
  save();

  res.json({ success: true, points_awarded: points });
});

app.post('/api/admin/invoices/:id/reject', auth('admin'), (req, res) => {
  const { reason } = req.body;
  const invoice = data.invoices.find(i => i.id === parseInt(req.params.id));
  if (!invoice || invoice.status !== 'pending') return res.status(400).json({ error: 'Invoice not found or already reviewed.' });
  invoice.status = 'rejected';
  invoice.reject_reason = reason || 'Not specified';
  invoice.reviewed_at = new Date().toISOString();
  save();
  res.json({ success: true });
});

app.get('/api/admin/redemptions', auth('admin'), (req, res) => {
  const status = req.query.status || 'pending';
  const rows = data.redemptions
    .filter(r => r.status === status)
    .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
    .map(r => {
      const m = data.members.find(m => m.id === r.member_id);
      const g = data.gift_catalogue.find(g => g.id === r.gift_id);
      return { ...r, full_name: m?.full_name, member_code: m?.member_code, item_name: g?.item_name };
    });
  res.json(rows);
});

app.post('/api/admin/redemptions/:id/approve', auth('admin'), (req, res) => {
  const { collection_date, collection_message } = req.body;
  const redemption = data.redemptions.find(r => r.id === parseInt(req.params.id));
  if (!redemption) return res.status(404).json({ error: 'Redemption not found.' });
  if (redemption.status !== 'pending') return res.status(400).json({ error: 'Already reviewed.' });

  redemption.status = 'approved';
  redemption.collection_date = collection_date || null;
  redemption.collection_message = collection_message || null;
  redemption.reviewed_at = new Date().toISOString();

  data.points_transactions.push({
    id: nextId('points_transactions'),
    member_id: redemption.member_id,
    invoice_id: null,
    redemption_id: redemption.id,
    type: 'redeemed',
    points: -redemption.points_deducted,
    note: 'Gift redemption approved',
    created_at: new Date().toISOString(),
  });
  save();

  res.json({ success: true });
});

app.post('/api/admin/redemptions/:id/reject', auth('admin'), (req, res) => {
  const { reason } = req.body;
  const redemption = data.redemptions.find(r => r.id === parseInt(req.params.id));
  if (!redemption || redemption.status !== 'pending') return res.status(400).json({ error: 'Not found or already reviewed.' });
  redemption.status = 'rejected';
  redemption.reject_reason = reason || 'Not specified';
  redemption.reviewed_at = new Date().toISOString();
  save();
  res.json({ success: true });
});

app.get('/api/admin/members', auth('admin'), (req, res) => {
  const rows = [...data.members]
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .map(m => ({ ...m, balance: getBalance(m.id) }));
  res.json(rows);
});

app.listen(PORT, () => {
  console.log(`Balaji Bath Square Loyalty app running at http://localhost:${PORT}`);
  console.log(`Admin panel: http://localhost:${PORT}/admin.html (admin / admin123 — change this)`);
});
