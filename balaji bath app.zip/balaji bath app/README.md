# Balaji Bath Square — Trade Rewards (Simple Version)

The same working loyalty program — registration, OTP login, invoice
submission, points, gift catalogue, redemptions, admin approvals — with
the simplest possible technology underneath.

## Why this version

The first version used SQLite (`better-sqlite3`), which needs a C++
compiler and Python to install on some machines — that's what caused the
`npm install` error you hit on Windows. This version has **zero native
dependencies**. The "database" is one plain JSON file
(`data/data.json`) that Node reads and writes directly. You can open it
in Notepad and see exactly what's stored.

Only three packages, all pure JavaScript:
- `express` — the web server
- `multer` — handles invoice file uploads
- `cors` — allows the front end to call the API

## Run it

```bash
npm install
npm start
```

Then open:
- **Member site:** http://localhost:3000
- **Admin panel:** http://localhost:3000/admin.html — login `admin` / `admin123`

No Python, no build tools, no database server to install. `npm install`
should finish in a few seconds.

## How OTP works right now

There's no real SMS gateway connected. When an OTP is requested, it's
logged to the server console **and** shown directly on the member's screen
(labelled "Dev mode") so you can test the whole flow without a phone.
Before real members use this, open `otp.js` and wire in a real provider
(MSG91, Twilio, etc.), and set `NODE_ENV=production` so the on-screen OTP
stops appearing.

## Where your data lives

Everything — members, invoices, points, redemptions — is in
`data/data.json`. To start over completely, stop the server and delete
that file; it's recreated empty (with the gift catalogue reseeded) the
next time you run `npm start`. Back this file up the same way you'd back
up any important document, once this is handling real members.

## Reward rates

| Category    | Rate  |
|-------------|-------|
| Plumber     | 0.75% |
| Contractor  | 1.00% |
| Architect   | 1.25% |

Change these in `store.js` → `REWARD_RATES`.

## Project structure

```
bbsl-simple/
├── server.js          Express app + all API routes
├── store.js            Reads/writes data/data.json, calculates balances
├── otp.js              OTP generation/verification (SMS stub)
├── data/data.json       Created automatically — your entire database
├── public/
│   ├── index.html       Member site
│   ├── admin.html        Admin panel
│   ├── css/style.css     Shared theme
│   └── js/app.js, admin.js
└── uploads/              Uploaded invoice files
```

## What's already fully working

Same as before — register, log in, submit invoices, admin verify/reject
with automatic points calculation, redeem gifts with point reservation,
admin approve/reject with collection details, live dashboards on both
sides.

## Before this goes live with real members

1. Connect a real SMS gateway for OTP (see above).
2. Add basic password hashing for the admin login.
3. Host it somewhere permanent (Render, Railway, or any VPS) instead of
   your own laptop.
4. Back up `data/data.json` regularly.
