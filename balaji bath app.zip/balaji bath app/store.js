const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, 'data', 'data.json');

// ---------- load or create the database file ----------
function freshData() {
  return {
    members: [],
    invoices: [],
    points_transactions: [],
    gift_catalogue: [
      { id: 1, slab_points: 500, item_name: 'Electric Kettle, Flask or Sandwich Maker', active: true },
      { id: 2, slab_points: 1000, item_name: 'Dry Iron, Mixer or Trimmer', active: true },
      { id: 3, slab_points: 2000, item_name: 'Earbuds or Smart Watch', active: true },
      { id: 4, slab_points: 5000, item_name: 'Trolley Bag or Premium Bluetooth Speaker', active: true },
      { id: 5, slab_points: 10000, item_name: 'JBL Speaker, Air Fryer, Smart Watch or Office Chair', active: true },
      { id: 6, slab_points: 25000, item_name: 'Premium Smartphone (Choose Model)', active: true },
    ],
    redemptions: [],
    sessions: [],
    admin_users: [{ id: 1, username: 'admin', password: 'admin123' }],
    counters: { members: 0, invoices: 0, points_transactions: 0, gift_catalogue: 6, redemptions: 0 },
  };
}

if (!fs.existsSync(path.join(__dirname, 'data'))) fs.mkdirSync(path.join(__dirname, 'data'));
if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify(freshData(), null, 2));

let data = JSON.parse(fs.readFileSync(FILE, 'utf8'));

// Save straight to disk after every change. Simple and safe for a
// single-admin, low-traffic loyalty program — no separate database
// server, no build tools, the whole "database" is this one JSON file.
function save() {
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

function nextId(collection) {
  data.counters[collection] = (data.counters[collection] || 0) + 1;
  return data.counters[collection];
}

// Reward rate per category (percentage of invoice amount, expressed as points).
const REWARD_RATES = { plumber: 0.0075, contractor: 0.01, architect: 0.0125 };

function getBalance(memberId) {
  return data.points_transactions
    .filter(t => t.member_id === memberId)
    .reduce((sum, t) => sum + t.points, 0);
}

function getPendingRedemptionReserve(memberId) {
  return data.redemptions
    .filter(r => r.member_id === memberId && r.status === 'pending')
    .reduce((sum, r) => sum + r.points_deducted, 0);
}

function getAvailableBalance(memberId) {
  return getBalance(memberId) - getPendingRedemptionReserve(memberId);
}

module.exports = { data, save, nextId, REWARD_RATES, getBalance, getPendingRedemptionReserve, getAvailableBalance };
