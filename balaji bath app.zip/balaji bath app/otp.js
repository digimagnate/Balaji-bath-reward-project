// In-memory OTP store: { mobile: { otp, expiresAt } }
// Fine for a single-process demo/dev server. For production with multiple
// server instances, move this to the database or Redis.
const store = new Map();
const OTP_TTL_MS = 5 * 60 * 1000; // 5 minutes

function generate(mobile) {
  const otp = String(Math.floor(100000 + Math.random() * 900000));
  store.set(mobile, { otp, expiresAt: Date.now() + OTP_TTL_MS });

  // ---- SMS GATEWAY GOES HERE ----
  // This is the one real integration left before this works with real
  // phones. Wire your provider's API call in below, e.g.:
  //   await fetch('https://api.msg91.com/api/v5/otp', { ... })
  // Until then, the OTP is only logged to the server console (and
  // returned in the API response when NODE_ENV !== 'production', purely
  // so you can test the whole flow without a real SMS account).
  console.log(`[BBSL OTP] ${mobile} -> ${otp} (valid 5 min)`);

  return otp;
}

function verify(mobile, submitted) {
  const entry = store.get(mobile);
  if (!entry) return false;
  if (Date.now() > entry.expiresAt) { store.delete(mobile); return false; }
  if (entry.otp !== String(submitted)) return false;
  store.delete(mobile);
  return true;
}

module.exports = { generate, verify };
